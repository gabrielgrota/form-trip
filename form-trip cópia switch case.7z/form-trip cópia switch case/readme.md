# Projeto de site de planejamento de viagens.

:br: Algumas funcionalildades:
Pode editar o título da página clicando sobre ele.
Você deve escolher se quer apenas uma rota (roundtrip) ou uma viagem entre dois países (multi-city).
Caso seja multi-city ele abrirá mais uma caixa para selecionar a cidade e país desejado.

Por enquanto é isso, como estou usando para estudos, site está todo em inglês.

---

:gb: Some functionalities:
You can edit the title of the page by clicking on it.
You must choose whether you want, just one route (roundtrip) or a trip between two countries (multi-city).
If it is multi-city it will open another box to select the desired city and country.

That's it for now, as I'm using it for studies, the site is all in English.
const date = new Date().toLocaleDateString();
document.getElementById("todayDate").innerHTML = `<h5>${date}</h5>`;

// first select
function update1(){
    var select1 = document.getElementById("flyingFrom");
    var value1 = select1.options[select1.selectedIndex].value;

    console.log(value1)

    if (value1 === 'BRA') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${bra.flag}'> <h3>${bra.airportCode}</h3> <p>${bra.airportName}</p> <p>${bra.city}</p>`;
    } else if (value1 === 'USA') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${usa.flag}'> <h3>${usa.airportCode}</h3> <p>${usa.airportName}</p> <p>${usa.city}</p>`;
    } else if (value1 === 'IDN') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${idn.flag}'> <h3>${idn.airportCode}</h3> <p>${idn.airportName}</p> <p>${idn.city}</p>`;
    } else if (value1 === 'ENG') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${eng.flag}'> <h3>${eng.airportCode}</h3> <p>${eng.airportName}</p> <p>${eng.city}</p>`;
    } else if (value1 === 'NZL') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${nzl.flag}'> <h3>${nzl.airportCode}</h3> <p>${nzl.airportName}</p> <p>${nzl.city}</p>`;
    } else if (value1 === 'JPN') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${jpn.flag}'> <h3>${jpn.airportCode}</h3> <p>${jpn.airportName}</p> <p>${jpn.city}</p>`;
    } else if (value1 === 'KOR') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${kor.flag}'> <h3>${kor.airportCode}</h3> <p>${kor.airportName}</p> <p>${kor.city}</p>`;
    } else if (value1 === 'ARG') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${arg.flag}'> <h3>${arg.airportCode}</h3> <p>${arg.airportName}</p> <p>${arg.city}</p>`;
    } else if (value1 === 'SWE') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${swe.flag}'> <h3>${swe.airportCode}</h3> <p>${swe.airportName}</p> <p>${swe.city}</p>`;
    } else if (value1 === 'CYM') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${cym.flag}'> <h3>${cym.airportCode}</h3> <p>${cym.airportName}</p> <p>${cym.city}</p>`;
    } else if (value1 === 'AUS') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${aus.flag}'> <h3>${aus.airportCode}</h3> <p>${aus.airportName}</p> <p>${aus.city}</p>`;
    } else if (value1 === 'AUT') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${aut.flag}'> <h3>${aut.airportCode}</h3> <p>${aut.airportName}</p> <p>${aut.city}</p>`;
    } else if (value1 === 'BEL') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${bel.flag}'> <h3>${bel.airportCode}</h3> <p>${bel.airportName}</p> <p>${bel.city}</p>`;
    } else if (value1 === 'BOL') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${bol.flag}'> <h3>${bol.airportCode}</h3> <p>${bol.airportName}</p> <p>${bol.city}</p>`;
    } else if (value1 === 'BWA') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${bwa.flag}'> <h3>${bwa.airportCode}</h3> <p>${bwa.airportName}</p> <p>${bwa.city}</p>`;
    } else if (value1 === 'CAN') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${can.flag}'> <h3>${can.airportCode}</h3> <p>${can.airportName}</p> <p>${can.city}</p>`;
    } else if (value1 === 'CHN') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${chn.flag}'> <h3>${chn.airportCode}</h3> <p>${chn.airportName}</p> <p>${chn.city}</p>`;
    } else if (value1 === 'CHL') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${chl.flag}'> <h3>${chl.airportCode}</h3> <p>${chl.airportName}</p> <p>${chl.city}</p>`;
    } else if (value1 === 'CZE') {
        document.getElementById("flyingFromSpan").innerHTML = `<img src='${cze.flag}'> <h3>${cze.airportCode}</h3> <p>${cze.airportName}</p> <p>${cze.city}</p>`;
    }
};
update1();

// second select
function update2(){
    var select2 = document.getElementById("flyingTo");
    var value2 = select2.options[select2.selectedIndex].value;

    console.log(value2)

    if (value2 === 'BRA') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${bra.flag}'> <h3>${bra.airportCode}</h3> <p>${bra.airportName}</p> <p>${bra.city}</p>`;
    } else if (value2 === 'USA') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${usa.flag}'> <h3>${usa.airportCode}</h3> <p>${usa.airportName}</p> <p>${usa.city}</p>`;
    } else if (value2 === 'IDN') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${idn.flag}'> <h3>${idn.airportCode}</h3> <p>${idn.airportName}</p> <p>${idn.city}</p>`;
    } else if (value2 === 'ENG') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${eng.flag}'> <h3>${eng.airportCode}</h3> <p>${eng.airportName}</p> <p>${eng.city}</p>`;
    } else if (value2 === 'NZL') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${nzl.flag}'> <h3>${nzl.airportCode}</h3> <p>${nzl.airportName}</p> <p>${nzl.city}</p>`;
    } else if (value2 === 'JPN') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${jpn.flag}'> <h3>${jpn.airportCode}</h3> <p>${jpn.airportName}</p> <p>${jpn.city}</p>`;
    } else if (value2 === 'KOR') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${kor.flag}'> <h3>${kor.airportCode}</h3> <p>${kor.airportName}</p> <p>${kor.city}</p>`;
    } else if (value2 === 'ARG') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${arg.flag}'> <h3>${arg.airportCode}</h3> <p>${arg.airportName}</p> <p>${arg.city}</p>`;
    } else if (value2 === 'SWE') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${swe.flag}'> <h3>${swe.airportCode}</h3> <p>${swe.airportName}</p> <p>${swe.city}</p>`;
    } else if (value2 === 'CYM') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${cym.flag}'> <h3>${cym.airportCode}</h3> <p>${cym.airportName}</p> <p>${cym.city}</p>`;
    } else if (value2 === 'AUS') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${aus.flag}'> <h3>${aus.airportCode}</h3> <p>${aus.airportName}</p> <p>${aus.city}</p>`;
    } else if (value2 === 'AUT') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${aut.flag}'> <h3>${aut.airportCode}</h3> <p>${aut.airportName}</p> <p>${aut.city}</p>`;
    } else if (value2 === 'BEL') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${bel.flag}'> <h3>${bel.airportCode}</h3> <p>${bel.airportName}</p> <p>${bel.city}</p>`;
    } else if (value2 === 'BOL') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${bol.flag}'> <h3>${bol.airportCode}</h3> <p>${bol.airportName}</p> <p>${bol.city}</p>`;
    } else if (value2 === 'BWA') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${bwa.flag}'> <h3>${bwa.airportCode}</h3> <p>${bwa.airportName}</p> <p>${bwa.city}</p>`;
    } else if (value2 === 'CAN') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${can.flag}'> <h3>${can.airportCode}</h3> <p>${can.airportName}</p> <p>${can.city}</p>`;
    } else if (value2 === 'CHN') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${chn.flag}'> <h3>${chn.airportCode}</h3> <p>${chn.airportName}</p> <p>${chn.city}</p>`;
    } else if (value2 === 'CHL') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${chl.flag}'> <h3>${chl.airportCode}</h3> <p>${chl.airportName}</p> <p>${chl.city}</p>`;
    } else if (value2 === 'CZE') {
        document.getElementById("flyingToSpan").innerHTML = `<img src='${cze.flag}'> <h3>${cze.airportCode}</h3> <p>${cze.airportName}</p> <p>${cze.city}</p>`;
    }
};
update2();

// multicity? yes. then...
function multiCityOption() {
    const selected = document.querySelector('input[name="opcao"]:checked').value;
    console.log(selected);

    if (selected === 'multiCity') {
        document.getElementById("multiCityFlecha").innerHTML = `<div class="flecha"><img class="flecha" src="images/flecha.png" alt="Flecha" /></div>`;
        document.getElementById("multiCitySelected").innerHTML = `
        <div class="local-date">
            <div class="local">
                <div class="flying">
                    <select name="flyingMultiCity" id="flyingMultiCity" onchange="update31()">
                        <option value="0" selected>Choose a city</option>
                        <option value="ARG">Buenos Aires, Argentina</option>
                        <option value="AUS">Sydney, Australia</option>
                        <option value="AUT">Vienna, Austria</option>
                        <option value="BEL">Brussels, Belgium</option>
                        <option value="BOL">Santa Cruz de la Sierra, Bolivia</option>
                        <option value="BRA">São Paulo, Brazil</option>
                        <option value="BWA">Gaborone, Botswana</option>
                        <option value="CAN">Ontario, Canada</option>
                        <option value="CHL">Santiago, Chile</option>
                        <option value="CHN">Beijing, China</option>
                        <option value="CYM">George Town, Cayman Islands</option>
                        <option value="CZE">Prague, Czech Republic</option>
                        <option value="ENG">London, England, UK</option>
                        <option value="IDN">Jakarta, Indonesia</option>
                        <option value="JPN">Narita, Japan</option>
                        <option value="KOR">Jung District, South Korea</option>
                        <option value="NZL">Auckland, New Zealand</option>
                        <option value="SWE">Stockholm, Sweden</option>
                        <option value="USA">New York, U.S</option>
                    </select>
                </div>

                <div class="flyingMultiCity">
                    <span id="flyingMultiCityData"></span>
                </div>
            </div>

            <!-- Date Info -->
            <div class="date">
              <div class="date3">
                <label for="test">Departure date</label>
                <input
                  type="date"
                  id="start"
                  name="trip-start"
                  value="2021-10-28"
                  min="2023-01-24"
                  max="2030-12-31"
                />
              </div>
            </div>  
        </div>`
    }
};
multiCityOption();

// third select
function update31() {
    const select3 = document.querySelector('select[id="flyingMultiCity"]').value;
    console.log(select3);

    if (select3 === 'BRA') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${bra.flag}'> <h3>${bra.airportCode}</h3> <p>${bra.airportName}</p> <p>${bra.city}</p>`;
    } else if (select3 === 'USA') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${usa.flag}'> <h3>${usa.airportCode}</h3> <p>${usa.airportName}</p> <p>${usa.city}</p>`;
    } else if (select3 === 'IDN') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${idn.flag}'> <h3>${idn.airportCode}</h3> <p>${idn.airportName}</p> <p>${idn.city}</p>`;
    } else if (select3 === 'ENG') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${eng.flag}'> <h3>${eng.airportCode}</h3> <p>${eng.airportName}</p> <p>${eng.city}</p>`;
    } else if (select3 === 'NZL') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${nzl.flag}'> <h3>${nzl.airportCode}</h3> <p>${nzl.airportName}</p> <p>${nzl.city}</p>`;
    } else if (select3 === 'JPN') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${jpn.flag}'> <h3>${jpn.airportCode}</h3> <p>${jpn.airportName}</p> <p>${jpn.city}</p>`;
    } else if (select3 === 'KOR') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${kor.flag}'> <h3>${kor.airportCode}</h3> <p>${kor.airportName}</p> <p>${kor.city}</p>`;
    } else if (select3 === 'ARG') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${arg.flag}'> <h3>${arg.airportCode}</h3> <p>${arg.airportName}</p> <p>${arg.city}</p>`;
    } else if (select3 === 'SWE') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${swe.flag}'> <h3>${swe.airportCode}</h3> <p>${swe.airportName}</p> <p>${swe.city}</p>`;
    } else if (select3 === 'CYM') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${cym.flag}'> <h3>${cym.airportCode}</h3> <p>${cym.airportName}</p> <p>${cym.city}</p>`;
    } else if (select3 === 'AUS') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${aus.flag}'> <h3>${aus.airportCode}</h3> <p>${aus.airportName}</p> <p>${aus.city}</p>`;
    } else if (select3 === 'AUT') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${aut.flag}'> <h3>${aut.airportCode}</h3> <p>${aut.airportName}</p> <p>${aut.city}</p>`;
    } else if (select3 === 'BEL') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${bel.flag}'> <h3>${bel.airportCode}</h3> <p>${bel.airportName}</p> <p>${bel.city}</p>`;
    } else if (select3 === 'BOL') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${bol.flag}'> <h3>${bol.airportCode}</h3> <p>${bol.airportName}</p> <p>${bol.city}</p>`;
    } else if (select3 === 'BWA') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${bwa.flag}'> <h3>${bwa.airportCode}</h3> <p>${bwa.airportName}</p> <p>${bwa.city}</p>`;
    } else if (select3 === 'CAN') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${can.flag}'> <h3>${can.airportCode}</h3> <p>${can.airportName}</p> <p>${can.city}</p>`;
    } else if (select3 === 'CHN') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${chn.flag}'> <h3>${chn.airportCode}</h3> <p>${chn.airportName}</p> <p>${chn.city}</p>`;
    } else if (select3 === 'CHL') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${chl.flag}'> <h3>${chl.airportCode}</h3> <p>${chl.airportName}</p> <p>${chl.city}</p>`;
    } else if (select3 === 'CZE') {
        document.getElementById("flyingMultiCityData").innerHTML = `<img src='${cze.flag}'> <h3>${cze.airportCode}</h3> <p>${cze.airportName}</p> <p>${cze.city}</p>`;
    };
};
update31();
# Projeto de site de planejamento de voô.

Estudei e coloquei em prática:
Interações com <select><option>Select e opção</option></select>
escolhendo a cidade e país que está partindo e deseja chegar.
Criei as informações do aeroporto de cada país usando Objects `let bra = {code: 'BRA', city: 'São Paulo, Brazil}` e pra escrever no HTML usei o document.getElementById + ("id no html") + innerHTML + o nome do object + a propriedade do object.
Exemplo:
document.getElementById("BRA").innerHTML = `<img src='${bra.image}'> <h3>${bra.code}</h3> <p>${bra.airport}</p> <p>${bra.city}</p>`;

**19/01/2023**
## idea to trip 018 project

~~colocar dados do airport no array
chamar o array no select option
mostrar bandeira, nome da cidade~~

~~multicity? yes entao:
criar/abrir/mostrar no html outro select para selecionar a cidade~~

~~mostrar data de hoje e horario~~

mudar as datas/calendarios

clicar no save:
escrever no html informações do voo
> salvar as informaçoes em variaveis para poder escrever no html

```js
Your trip info:
You choose a ${roundtrip or multicity} International Trip,
you will go to countries, respectively, ${1st country} and ${2nd country}

(if multicity selected)
you will go to countries, respectively, ${1st country}, ${2nd country} and ${3rd country}

Departure date from your local, time
Departure date from your 1st country, time

(if multicity selected)
Departure date from your 2nd country, time
```

~~conseguir renomear o nome da trip "Trip 018"~~

colocar para display tela celular

ver se consigo fazer tradução, cliente escolher idioma desejado no começo
[link](https://www.youtube.com/watch?v=j_VJQYpbP34)

colocar valor da data de hoje no input do calendario

alguém pode me ajudar? dúvida de js
eu tenho vários objects com uma propriedade, exemplo: bra={city: "SP"}, e quero escrever o valor de city em um <option> no html, mas de uma forma que todas as outras propriedades com valores diferentes tb apareçam como opções no select.

colocar as opções do select somente escrevendo no html pelo javascript

separar scripts?
1 - objetos com as informações
2 - código e functions

automatizar processo de adicionar país.

criar api?

ver switch no lugar da function, conseguir uma função só para todos os select